import { DataTypes } from "sequelize";
import { connectSQL } from "../providers/db/sqlDbProvider.js";
import activeDbConfig from "../config/activeDbConfig.js";

let Model = null;

if (activeDbConfig.type === "sql") {
  const sequelize = connectSQL(activeDbConfig.sql);
  Model = sequelize.define("SQLOrganization", {
    name: { type: DataTypes.STRING },
    description: { type: DataTypes.TEXT },
    status: { type: DataTypes.STRING },
  });
}

export default Model;