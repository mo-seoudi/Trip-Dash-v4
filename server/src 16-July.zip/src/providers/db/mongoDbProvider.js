import mongoose from "mongoose";
import dotenv from "dotenv";
import activeDbConfig from "../../config/activeDbConfig.js";

dotenv.config();

if (activeDbConfig.type === "mongo") {
  mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });
}

export default mongoose;
export const Schema = mongoose.Schema;
