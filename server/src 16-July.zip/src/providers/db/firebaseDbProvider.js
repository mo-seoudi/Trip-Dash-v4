import { db } from "../../config/firebaseAdmin.js";
export default db;
