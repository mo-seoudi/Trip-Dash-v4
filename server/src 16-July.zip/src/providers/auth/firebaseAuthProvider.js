import { auth } from "../../config/firebaseAdmin.js";

export async function verifyToken(token) {
  return await auth.verifyIdToken(token);
}
