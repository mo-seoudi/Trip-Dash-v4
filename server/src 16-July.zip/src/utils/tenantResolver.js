import  activeDb from "../config/activeDbConfig.js";

// Import only provider abstractions
import firebaseDb from "../providers/db/firebaseDbProvider.js";
import mongoose from "../providers/db/mongoDbProvider.js";
import { connectSQL } from "../providers/db/sqlDbProvider.js";

const sequelize = connectSQL();
/**
 * Dynamically fetches tenant configuration from the selected database.
 * @param {string} tenantId - The tenant identifier.
 * @returns {Promise<Object>} Tenant configuration object.
 */
export async function getTenantConfig(tenantId) {
  switch (activeDb) {
    case "firebase": {
      const db = firebaseDb(); // returns admin.firestore()
      const doc = await db.collection("tenants").doc(tenantId).get();
      if (!doc.exists) {
        throw new Error("Tenant not found in Firebase");
      }
      return { id: doc.id, ...doc.data() };
    }

    case "mongo": {
      const schema = new mongoose.Schema({}, { strict: false });
      const Tenant = mongoose.model("Tenant", schema);
      const tenant = await Tenant.findById(tenantId);
      if (!tenant) {
        throw new Error("Tenant not found in MongoDB");
      }
      return tenant.toObject();
    }

    case "sql": {
      const [results] = await sequelize.query("SELECT * FROM tenants WHERE id = ?", {
        replacements: [tenantId],
      });
      if (!results.length) {
        throw new Error("Tenant not found in SQL");
      }
      return results[0];
    }

    default:
      throw new Error("Unsupported database provider in activeDbConfig");
  }
}
