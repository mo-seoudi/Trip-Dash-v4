export default {
  type: "firebase", // Change to "mongo" or "sql" as needed

  sql: {
    url: process.env.SQL_DB_URL,
    options: {},
  },

  mongo: {
    uri: process.env.MONGO_URI,
  },

  firebase: {
    projectId: process.env.FIREBASE_PROJECT_ID,
    clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
    privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, "\n"),
  },
};