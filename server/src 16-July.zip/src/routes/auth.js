import express from "express";
import fetch from "node-fetch";
import { auth, db } from "../config/firebaseAdmin.js";

const router = express.Router();

router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    // Sign in via Firebase REST API
    const response = await fetch(
      `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${process.env.FIREBASE_API_KEY}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, returnSecureToken: true }),
      }
    );
    const data = await response.json();

    if (data.error) {
      return res.status(401).json({ message: data.error.message });
    }

    // Check Firestore profile
    const userDoc = await db.collection("users").doc(data.localId).get();
    if (!userDoc.exists) {
      return res.status(403).json({ message: "Profile not found. Please contact admin." });
    }

    const userData = userDoc.data();
    if (userData.status !== "approved") {
      return res.status(403).json({ message: "Your account is pending approval." });
    }

    res.json({ token: data.idToken });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Login failed" });
  }
});

router.post("/register", async (req, res) => {
  const { email, password } = req.body;

  try {
    // Create user in Firebase Auth
    const userRecord = await auth.createUser({
      email,
      password,
    });

    // Create Firestore user profile
    await db.collection("users").doc(userRecord.uid).set({
      email,
      status: "pending", // Or "approved" if you want instant access
      createdAt: new Date(),
    });

    // Sign in immediately to get ID token
    const response = await fetch(
      `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${process.env.FIREBASE_API_KEY}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, returnSecureToken: true }),
      }
    );
    const data = await response.json();

    if (data.error) {
      return res.status(400).json({ message: data.error.message });
    }

    res.json({ token: data.idToken });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Registration failed" });
  }
});

export default router;
