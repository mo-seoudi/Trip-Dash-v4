import activeDbConfig from "../config/activeDbConfig.js";

import { FirebaseTripRepository } from "../repositories/firebase/FirebaseTripRepository.js";
import { MongoTripRepository } from "../repositories/mongo/MongoTripRepository.js";
import { SQLTripRepository } from "../repositories/sql/SQLTripRepository.js";

import { FirebaseTenantRepository } from "../repositories/firebase/FirebaseTenantRepository.js";
import { MongoTenantRepository } from "../repositories/mongo/MongoTenantRepository.js";
import { SQLTenantRepository } from "../repositories/sql/SQLTenantRepository.js";

import { FirebaseUserRepository } from "../repositories/firebase/FirebaseUserRepository.js";
import { MongoUserRepository } from "../repositories/mongo/MongoUserRepository.js";
import { SQLUserRepository } from "../repositories/sql/SQLUserRepository.js";

import { FirebaseSettingsRepository } from "../repositories/firebase/FirebaseSettingsRepository.js";
import { MongoSettingsRepository } from "../repositories/mongo/MongoSettingsRepository.js";
import { SQLSettingsRepository } from "../repositories/sql/SQLSettingsRepository.js";

import { SQLOrganizationRepository } from "../repositories/sql/SQLOrganizationRepository.js";
import { SQLPartnershipRepository } from "../repositories/sql/SQLPartnershipRepository.js";
import { MongoOrganizationRepository } from "../repositories/mongo/MongoOrganizationRepository.js";
import { MongoPartnershipRepository } from "../repositories/mongo/MongoPartnershipRepository.js";
import { FirebaseOrganizationRepository } from "../repositories/firebase/FirebaseOrganizationRepository.js";
import { FirebasePartnershipRepository } from "../repositories/firebase/FirebasePartnershipRepository.js";

function getDbType() {
  return activeDbConfig.type;
}

// 🔥 Trip resolver
export function getTripRepository() {
  const type = getDbType();
  if (type === "firebase") return new FirebaseTripRepository(activeDbConfig.firebase);
  if (type === "mongo") return new MongoTripRepository(activeDbConfig.mongo);
  if (type === "sql") return new SQLTripRepository(activeDbConfig.sql);
  throw new Error("Unsupported database type");
}

// 🏢 Tenant resolver
export function getTenantRepository() {
  const type = getDbType();
  if (type === "firebase") return new FirebaseTenantRepository(activeDbConfig.firebase);
  if (type === "mongo") return new MongoTenantRepository(activeDbConfig.mongo);
  if (type === "sql") return new SQLTenantRepository(activeDbConfig.sql);
  throw new Error("Unsupported database type");
}

// 👤 User resolver
export function getUserRepository() {
  const type = getDbType();
  if (type === "firebase") return new FirebaseUserRepository(activeDbConfig.firebase);
  if (type === "mongo") return new MongoUserRepository(activeDbConfig.mongo);
  if (type === "sql") return new SQLUserRepository(activeDbConfig.sql);
  throw new Error("Unsupported database type");
}

// ⚙️ Settings resolver
export function getSettingsRepository() {
  const type = getDbType();
  if (type === "firebase") return new FirebaseSettingsRepository(activeDbConfig.firebase);
  if (type === "mongo") return new MongoSettingsRepository(activeDbConfig.mongo);
  if (type === "sql") return new SQLSettingsRepository(activeDbConfig.sql);
  throw new Error("Unsupported database type");
}

// 🏫 Organization resolver
export function getOrganizationRepository() {
  const type = getDbType();
  if (type === "firebase") return new FirebaseOrganizationRepository(activeDbConfig.firebase);
  if (type === "mongo") return new MongoOrganizationRepository(activeDbConfig.mongo);
  if (type === "sql") return new SQLOrganizationRepository(activeDbConfig.sql);
  throw new Error("Unsupported database type");
}

// 🤝 Partnership resolver
export function getPartnershipRepository() {
  const type = getDbType();
  if (type === "firebase") return new FirebasePartnershipRepository(activeDbConfig.firebase);
  if (type === "mongo") return new MongoPartnershipRepository(activeDbConfig.mongo);
  if (type === "sql") return new SQLPartnershipRepository(activeDbConfig.sql);
  throw new Error("Unsupported database type");
}
