import { getTenantConfig } from "./tenantService.js";

export async function verifyToken(token, tenantId) {
  const tenantConfig = await getTenantConfig(tenantId);
  let authProvider;

  if (tenantConfig.authProvider === "firebase") {
    authProvider = await import("../providers/auth/firebaseAuthProvider.js");
  } else if (tenantConfig.authProvider === "auth0") {
    authProvider = await import("../providers/auth/auth0Provider.js");
  } else if (tenantConfig.authProvider === "msGraph") {
    authProvider = await import("../providers/auth/msGraphAuthProvider.js");
  } else {
    throw new Error("Unknown auth provider");
  }

  return await authProvider.verifyToken(token);
}
