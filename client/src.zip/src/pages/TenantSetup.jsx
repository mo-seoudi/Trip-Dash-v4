import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

export default function TenantConfigSetupPage() {
  const [formData, setFormData] = useState({
    tenantId: "",
    name: "",
    dbProvider: "firebase",
    firebase: {
      apiKey: "",
      projectId: "",
      privateKey: "",
      clientEmail: ""
    },
    mongo: {
      uri: ""
    },
    sql: {
      host: "",
      user: "",
      password: ""
    }
  });

  const handleChange = (e, path = []) => {
    const { name, value } = e.target;
    setFormData(prev => {
      const updated = { ...prev };
      if (path.length > 0) {
        path.reduce((obj, key, i) => {
          if (i === path.length - 1) obj[key] = value;
          return obj[key];
        }, updated);
      } else {
        updated[name] = value;
      }
      return updated;
    });
  };

  const handleSubmit = async () => {
    try {
      const response = await fetch("/api/admin/tenant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData)
      });
      const data = await response.json();
      alert("Tenant config saved: " + JSON.stringify(data));
    } catch (err) {
      alert("Error: " + err.message);
    }
  };

  const provider = formData.dbProvider;

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <Card>
        <CardContent className="space-y-4">
          <h2 className="text-xl font-bold">Tenant Configuration</h2>
          <div>
            <Label>Tenant ID</Label>
            <Input name="tenantId" value={formData.tenantId} onChange={handleChange} />
          </div>
          <div>
            <Label>Name</Label>
            <Input name="name" value={formData.name} onChange={handleChange} />
          </div>
          <div>
            <Label>Database Provider</Label>
            <select
              name="dbProvider"
              value={formData.dbProvider}
              onChange={handleChange}
              className="border p-2 rounded w-full"
            >
              <option value="firebase">Firebase</option>
              <option value="mongo">MongoDB</option>
              <option value="sql">SQL</option>
            </select>
          </div>

          {provider === "firebase" && (
            <>
              <div>
                <Label>API Key</Label>
                <Input
                  value={formData.firebase.apiKey}
                  onChange={e => handleChange(e, ["firebase", "apiKey"])}
                />
              </div>
              <div>
                <Label>Project ID</Label>
                <Input
                  value={formData.firebase.projectId}
                  onChange={e => handleChange(e, ["firebase", "projectId"])}
                />
              </div>
              <div>
                <Label>Client Email</Label>
                <Input
                  value={formData.firebase.clientEmail}
                  onChange={e => handleChange(e, ["firebase", "clientEmail"])}
                />
              </div>
              <div>
                <Label>Private Key</Label>
                <Textarea
                  rows={4}
                  value={formData.firebase.privateKey}
                  onChange={e => handleChange(e, ["firebase", "privateKey"])}
                />
              </div>
            </>
          )}

          {provider === "mongo" && (
            <div>
              <Label>Mongo URI</Label>
              <Input
                value={formData.mongo.uri}
                onChange={e => handleChange(e, ["mongo", "uri"])}
              />
            </div>
          )}

          {provider === "sql" && (
            <>
              <div>
                <Label>Host</Label>
                <Input
                  value={formData.sql.host}
                  onChange={e => handleChange(e, ["sql", "host"])}
                />
              </div>
              <div>
                <Label>User</Label>
                <Input
                  value={formData.sql.user}
                  onChange={e => handleChange(e, ["sql", "user"])}
                />
              </div>
              <div>
                <Label>Password</Label>
                <Input
                  type="password"
                  value={formData.sql.password}
                  onChange={e => handleChange(e, ["sql", "password"])}
                />
              </div>
            </>
          )}

          <Button className="mt-4 w-full" onClick={handleSubmit}>
            Save Tenant Config
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
