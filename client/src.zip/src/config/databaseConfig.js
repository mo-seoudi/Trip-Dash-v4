// src/config/databaseConfig.js
export const databaseType = "firebase"; // or "customAPI", "sql", etc.

export const firebaseConfig = {
  apiKey: "XXX",
  authDomain: "XXX",
  projectId: "XXX",
  storageBucket: "XXX",
  messagingSenderId: "XXX",
  appId: "XXX",
};
